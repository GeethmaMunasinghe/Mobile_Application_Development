package com.example.practical01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
