package com.example.practical02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
