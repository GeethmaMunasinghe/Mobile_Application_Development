package com.example.formvalidation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
